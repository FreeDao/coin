/**   
* @Title: FinalChenBaseActivity.java
* @Package net.tsz.afinal
* @Description: TODO(用一句话描述该文件做什么)
* @author 陈红建
* @date 2013-7-27 下午3:13:23
* @version V1.0
*/ 
package net.tsz.afinal;

import android.app.Activity;

/** 
 * @ClassName: FinalChenBaseActivity
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @author 陈红建
 * @date 2013-7-27 下午3:13:23
 * 
 */
public class FinalChenBaseActivity extends Activity
{

}

