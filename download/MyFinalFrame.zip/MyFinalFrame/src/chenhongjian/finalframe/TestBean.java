/**   
* @Title: TestBean.java
* @Package chenhongjian.finalframe
* @Description: TODO(用一句话描述该文件做什么)
* @author 陈红建
* @date 2013-7-26 下午2:51:26
* @version V1.0
*/ 
package chenhongjian.finalframe;

/** 
 * @ClassName: TestBean
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @author 陈红建
 * @date 2013-7-26 下午2:51:26
 * 
 */
public class TestBean
{

	private String age;
	private String name;
	public String getAge()
	{
		return age;
	}
	public void setAge(String age)
	{
		this.age = age;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	
}

