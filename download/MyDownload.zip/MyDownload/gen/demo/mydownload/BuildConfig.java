/** Automatically generated file. DO NOT MODIFY */
package demo.mydownload;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}